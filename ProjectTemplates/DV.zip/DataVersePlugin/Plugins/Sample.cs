﻿using Microsoft.Xrm.Sdk;
using System;
using TI.DV.Shared;
using $safeprojectname$.Constants;

namespace $safeprojectname$.Plugins
{
    /* 
     * Plugin development guide: https://docs.microsoft.com/powerapps/developer/common-data-service/plug-ins
     * Best practices and guidance: https://docs.microsoft.com/powerapps/developer/common-data-service/best-practices/business-logic/
     */
    public class Sample : PluginBase
    {
        public Sample() : base(typeof(Sample))
        {
        }
        public Sample(string unsecureConfiguration, string secureConfiguration)
            : base(typeof(Sample))
        {
            // TODO: Implement your custom configuration handling
            // https://docs.microsoft.com/powerapps/developer/common-data-service/register-plug-in#set-configuration-data
        }
        // Entry point for custom business logic execution
        protected override void ExecuteCdsPlugin(ILocalPluginContext localPluginContext)
        {
            if (localPluginContext is null)
            {
                throw new ArgumentNullException(nameof(localPluginContext));
            }
            var context = localPluginContext.PluginExecutionContext;
            var service = localPluginContext.CurrentUserService;
            var tracer = localPluginContext.TracingService;

            if(context.InputParameters.Contains(InputParameter.Target) && context.InputParameters[InputParameter.Target] is Entity)
            {
                switch (context.MessageName)
                {
                    case Message.Create:
                        {
                            var target = (Entity)context.InputParameters[InputParameter.Target];
                            switch (target.LogicalName)
                            {
                                case Tables.Contact:
                                    switch (context.Stage)
                                    {
                                        case Stage.PreValidation:

                                            // Code if plugin registered on PreValidation.
                                            break;
                                        case Stage.PreOperation:
                                            // Code if plugin registered on PreOperation.
                                            break;
                                        case Stage.PostOperation:
                                            // Code if plugin registered on PostOperation.
                                            break;
                                        default:
                                            throw new ArgumentOutOfRangeException($"Plugin not registered on stage {context.Stage}");
                                    }
                                    break;
                                default:
                                    throw new ArgumentOutOfRangeException($"Plugin not registered for entity {target.LogicalName}");
                            }

                        }
                        break;
                    case Message.Update:
                        break;
                    default:
                        throw new ArgumentOutOfRangeException($"Plugin not registered for {context.MessageName}");
                }

            }

            
        }
    }
}
