﻿using System;
using Microsoft.Xrm.Sdk;

namespace $safeprojectname$.Extensions
{
    public static class OrgServiceExtensions 
    {
        public static void  SampleExtension(this IOrganizationService service , string parameter)
        {
            throw new NotImplementedException();
        }
    }
}
