﻿namespace $safeprojectname$.Constants
{
    public static class Stage
    {
        public const int PreValidation = 10;
        public const int PreOperation = 20;
        public const int PostOperation = 40;
    }
}
