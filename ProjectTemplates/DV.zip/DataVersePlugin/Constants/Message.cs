﻿namespace $safeprojectname$.Constants
{
    public static class Message
    {
        public const string Create = "Create";
        public const string Update = "Update";
        public const string Delete = "Delete";
    }
}
