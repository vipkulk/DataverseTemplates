﻿namespace $safeprojectname$.Constants
{
    public static class EntityImage
    {
        public const string Default = "Image";
    }
}
