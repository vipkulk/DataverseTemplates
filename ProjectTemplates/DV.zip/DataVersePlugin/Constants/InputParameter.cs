﻿namespace $safeprojectname$.Constants
{
    public static class InputParameter
    {
        public const string Target = "Target";
    }
}
