﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using TI.DV.Shared;

namespace $safeprojectname$.Entities
{
    [EntityLogicalName(Tables.Contact)]
    public sealed class Contact : Entity
    {
        public string FirstName 
        { 
            get=> GetAttributeValue<string>(ContactTable.FirstName); 
            set=> this[ContactTable.FirstName] = value; 
        }

        public string LastName
        {
            get => GetAttributeValue<string>(ContactTable.LastName);
            set => this[ContactTable.LastName] = value;
        }

        public EntityReference Customer
        {
            get => GetAttributeValue<EntityReference>(ContactTable.Customer);
            set => this[ContactTable.Customer] = value;
        }
    }
}
