"use strict";
/// <reference path="../../common/definition/index.d.ts" />
var TI;
(function (TI) {
    var Sample;
    (function (Sample) {
        var WebResources;
        (function (WebResources) {
            var Scripts;
            (function (Scripts) {
                var Entities;
                (function (Entities) {
                    var Account;
                    (function (Account) {
                        'use strict';
                        /**
                         * Class to be used for the Account Form Scripting
                         * */
                        var FormLibrary = /** @class */ (function () {
                            function FormLibrary() {
                                this._utils = new Scripts.Common.Utility();
                            }
                            /**
                             * Function to be called on load of the form
                             * @param {Xrm.Events.EventContext} executionContext Execution Context object
                             */
                            FormLibrary.prototype.onLoad = function (executionContext) {
                                var functionName = "onLoad";
                                try {
                                    // Get the Form Context
                                    var formContext = TI_ACCFormLibrary._utils.getFormContext(executionContext);
                                }
                                catch (e) {
                                    TI_ACCFormLibrary._utils.handleError(functionName, e);
                                }
                            };
                            return FormLibrary;
                        }());
                        Account.FormLibrary = FormLibrary;
                    })(Account = Entities.Account || (Entities.Account = {}));
                })(Entities = Scripts.Entities || (Scripts.Entities = {}));
            })(Scripts = WebResources.Scripts || (WebResources.Scripts = {}));
        })(WebResources = Sample.WebResources || (Sample.WebResources = {}));
    })(Sample = TI.Sample || (TI.Sample = {}));
})(TI || (TI = {}));
// In CRM use TI_ACCFormLibrary.onLoad
var TI_ACCFormLibrary = new $safeprojectname$.Scripts.Entities.Account.FormLibrary();
/* *
 * 1. Use Gulp to bundle files
 * 2. In CRM use TI_ACCFormLibrary.onLoad
 * */ 
//# sourceMappingURL=FormLibrary.js.map