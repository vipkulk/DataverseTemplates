﻿/// <reference path="../../common/definition/index.d.ts" />

namespace $safeprojectname$.Scripts.Entities.Account {
    'use strict';
    /**
     * Class to be used for the Account Form Scripting
     * */
    export class FormLibrary {
        'use strict';
        // Private Global Variables
        private _utils: Common.Utility;

        constructor() {
            this._utils = new Common.Utility();
        }

        /**
         * Function to be called on load of the form
         * @param {Xrm.Events.EventContext} executionContext Execution Context object
         */
        public onLoad(executionContext: Xrm.Events.EventContext): void {
            let functionName: string = "onLoad";
            try {
                // Get the Form Context
                let formContext: Xrm.FormContext = TI_ACCFormLibrary._utils.getFormContext(executionContext);
            }
            catch (e) {
                TI_ACCFormLibrary._utils.handleError(functionName, e);
            }
        }
    }
}

// In CRM use TI_ACCFormLibrary.onLoad
let TI_ACCFormLibrary = new $safeprojectname$.Scripts.Entities.Account.FormLibrary();

/* *
 * 1. Use Gulp to bundle files
 * 2. In CRM use TI_ACCFormLibrary.onLoad
 * */