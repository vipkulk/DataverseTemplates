﻿/// <reference path="definition/index.d.ts" />

namespace $safeprojectname$.Scripts.Common {
    /**
     * All the common utility functions will reside in this class
     * */
    export class Utility {
        
        /**
         * Function to validate the execution context and get the Form Context
         * @param {Xrm.Events.EventContext} executionContext The object of the execution contect
         * @returns {Xrm.FormContext} Obtained Form Context
         */
      getFormContext(executionContext: Xrm.Events.EventContext): Xrm.FormContext {
            try {
                // Validate the Execution Context or else throw error
                if (TI_Utility.isValid(executionContext)) {
                    // Validate the Form Context or else throw error
                    if (TI_Utility.isValid(executionContext.getFormContext) && TI_Utility.isValid(executionContext.getFormContext()))
                        return executionContext.getFormContext();
                    else throw new Error(`Unable to obtain Form Context.`);
                }
                else throw new Error(`Unable to obtain Execution Context.`);
            } catch (e) {
                throw new Error(e.message);
            }
        }

        /**
         * Generic function to obtain the attribute object
         * @param {string} attributeName Logical Name of the attribute to be obtained
         * @param {Xrm.FormContext} formContext Form Context object
         * @returns {Xrm.Attributes.Attribute} The obtained attribute object
         */
        getAttribute(attributeName: string, formContext: Xrm.FormContext): Xrm.Attributes.Attribute {
            try {
                // Validate the Attribute Name or else throw error
                if (TI_Utility.isValid(attributeName)) {
                    // Validate the getAttribute or else throw error
                    if (TI_Utility.isValid(formContext.getAttribute) && TI_Utility.isValid(formContext.getAttribute(attributeName)))
                        return formContext.getAttribute(attributeName);
                    else throw new Error(`Could not obtain attribute with the logical name ${attributeName}`);
                }
                else throw new Error(`attributeName parameter is invalid`);
            }
            catch (e) {
                throw new Error(e.message);
            }
        }

        /**
         * Generic function to obtain the control object
         * @param {string} attributeName Logical Name of the control to be obtained
         * @param {Xrm.FormContext} formContext Form Context object
         * @returns {Xrm.Controls.Control} The obtained control object
         */
        getControl(controlName: string, formContext: Xrm.FormContext): Xrm.Controls.Control {
            try {
                // Validate the Control Name or else throw error
                if (TI_Utility.isValid(controlName)) {
                    // Validate the getAttribute or else throw error
                    if (TI_Utility.isValid(formContext.ui) && TI_Utility.isValid(formContext.ui.controls)
                        && TI_Utility.isValid(formContext.ui.controls.get(controlName)))
                        return formContext.ui.controls.get(controlName);
                    else throw new Error(`Could not obtain control with the logical name ${controlName}`);
                }
                else throw new Error(`controlName parameter is invalid`);
            }
            catch (e) {
                throw new Error(e.message);
            }
        }

        /**
         * Generic function to get the Tab
         * @param {string} tabName Logical Name of the tab to be obtained
         * @param {Xrm.FormContext} formContext Form Context object
         * @returns {Xrm.Controls.Tab} The obtained Tab object
         */
        getTab(tabName: string, formContext: Xrm.FormContext): Xrm.Controls.Tab {
            try {
                // Validate the parameter tabName or else throw error
                if (TI_Utility.isValid(tabName)) {
                    // Validate the tab or else throw error
                    if (TI_Utility.isValid(formContext.ui) && TI_Utility.isValid(formContext.ui.tabs)
                        && TI_Utility.isValid(formContext.ui.tabs.get) && TI_Utility.isValid(formContext.ui.tabs.get(tabName)))
                        return formContext.ui.tabs.get(tabName);
                    else throw new Error(`Couldn't obtain tab with the logical name ${tabName}`);
                }
                else throw new Error(`tabName parameter is invalid`);
            } catch (e) {
                throw new Error(e.message);
            }
        }

        /**
         * Generic function to show/hide elements
         * @param {string} name Element Name
         * @param {string} type Element Type
         * @param {boolean} show true for visible and false for hidden
         * @param {Xrm.FormContext} formContext Form Context
         * @param {Xrm.Controls.Tab} tab To be provided only in the case of section element type
         */
        showElement(name: string, type: string, show: boolean, formContext: Xrm.FormContext, tab?: Xrm.Controls.Tab): void {
            let functionName: string = "showElement";
            try {
                switch (type) {
                    case 'column':
                        break;
                    case 'tab':
                        if (TI_Utility.isValid(formContext.ui.tabs.get(name)))
                            formContext.ui.tabs.get(name).setVisible(show);
                        break;
                    case 'section':
                        if (TI_Utility.isValid(tab.sections.get(name)))
                            tab.sections.get(name).setVisible(show);
                        break;
                }
            } catch (e) {
                throw new Error(e.message);
            }
        }

        /**
         * Alter the state of the control based on the parameter provided
         * @param {boolean} value True: To disabled the control; False: To enabled the control 
         * @param {Xrm.FormContext} formContext Form Context
         */
        disableAllControls(value: boolean, formContext: Xrm.FormContext): void {
            try {
                // Validate the control
                if (TI_Utility.isValid(formContext.ui) && TI_Utility.isValid(formContext.ui.controls))
                    // Loop through each one of them and disable the control
                    formContext.ui.controls.forEach((control) => {
                        // @ts-ignore
                        // Validate if the current control state is equal to the passed parameter, then do nothing
                        if (control.getDisabled() !== value) {
                            // @ts-ignore
                            control.setDisabled(value);
                        }
                    });
                else
                    throw new Error("Something went wrong");
            } catch (e) {
                throw new Error(e.message);
            }
        }

        /**
         * Generic method to show the alert
         * @param {string} msg Message to be shown
         * @param {string} msgTitle Title to be shown for the alert box
         * @param {string} btnLabel (optional) The button label for the alert box. Default: Yes
         * @param {number} height (optional) The height of the alert box. Default: 120
         * @param {number} width (optional) The width of the alert box. Default: 260
         * @param {(r: any) => any} successCallback (optional) The successcallback to be called on close of the alert box
         * @param {(e: any) => any} errorCallback (optional) The errorcallback to be called in case of error
         */
        showAlert(msg: string, msgTitle: string, btnLabel?: string, height?: number, width?: number, successCallback?: (r: any) => any, errorCallback?: (e: any) => any): void {
            try {
                let alertStrings: Xrm.Navigation.AlertStrings = { confirmButtonLabel: btnLabel || "Yes", text: msg, title: msgTitle };
                let alertOptions: Xrm.Navigation.DialogSizeOptions = { height: height || 120, width: width || 260 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions).then(successCallback, errorCallback);
            }
            catch (e) {
                throw new Error(e.message);
            }
        }

        /**
         * Generic function to refresh the form
         * @param {string} entityName Logical name of the entity to display the form for
         * @param {string} recordId ID of the record to display the form for
         */
        refreshForm(entityName: string, recordId: string): void {
            try {
                let entityFormOptions: Xrm.Navigation.EntityFormOptions = { entityName: entityName, entityId: recordId };
                Xrm.Navigation.openForm(entityFormOptions);
            }
            catch (e) {
                throw new Error(e.message);
            }
        }        

        /**
         * Generic function to validate the items passed to it
         * @param {any} item
         * @returns {boolean} indicates whether the passed item is a valid item or not
         */
        private isValid(item: any): boolean {
            let functionName: string = "isValid";
            let valid: boolean = false;
            try {
                if (item !== null && item !== undefined && item !== "undefined" && item !== "null" && item !== "")
                    valid = true;
            } catch (e) {
                throw new Error(e.message);
            }
            return valid;
        }

        /**
         * Generic funtion to handle errors
         * @param {string} functionName Name of the Function from where the error is raised
         * @param {any} error The error object that needs to be handled
         */
        handleError(functionName: string, error: any) {
            if (error instanceof Error) {
                TI_Utility.showAlert(`${error.message}`, "Error", "OK");
            }
            else if (TI_Utility.isValid(error) && TI_Utility.isValid(error.message)) {
                TI_Utility.showAlert(`${error.message}`, "Error", "OK");
            }
            else {
                TI_Utility.showAlert(`${error}`, "Error", "OK");
            }
        }
    }    
}

let TI_Utility = new $safeprojectname$.Scripts.Common.Utility();