/**
 * Author: Parth
 * Version: 1.0.0.0
 * Instruction to get started:
 * Make this file part of your project
 * Follow the blog: https://medium.com/gulpjs/gulp-sips-command-line-interface-e53411d4467 for proper gulp installation
 * Install below packages:
 * npm install ts-node --save-dev
 * npm install typescript --save
 * npm install @types/node --save-dev
 * npm install --save-dev gulp-uglify
 * npm install --save-dev gulp-concat
 * npm install gulp
 * First install npm install --save-dev gulp-js-obfuscator 
 * if above doesn't work in your case then install npm install --save gulp-javascript-obfuscator
 */

const { src, dest, task } = require('gulp');
const uglifyjs = require('uglify-js');
const uglify = require('gulp-uglify');
var composer = require('gulp-uglify/composer');
const concat = require('gulp-concat');
// const javascriptObfuscator = require('gulp-javascript-obfuscator'); // based on what you use, uncomment this and comment the below one.
const jsObfuscator = require('gulp-js-obfuscator');

/**
 * Kindly put the proper path
 * srcPath will be the path of your JS
 * destPath will be the Output Directory of your JS
 */
let srcPaths: string[] = ["Scripts/Common/Utility.js", "Scripts/Entities/TableConfiguration/FormLibrary.js"];
// Example: let srcPaths: string[] = ['scripts/**/*.js', '!scripts/vendor/**', 'scripts/vendor/react.js'];
let destPath: string = "bundles/";

// This is to create the object of uglifyjs which can be later down use to pass the various parameters
// various available parameters: https://github.com/mishoo/UglifyJS2#minify-options
var minify = composer(uglifyjs, console);
// Created an object with the necessary parameters for uglification
var options = { mangle: { toplevel: true, eval: true } };
// ar options = { compress : { }  };

// Use following command: gulp concat-account-form
task('concat-account-form', async function (){
    src(["Scripts/Common/Utility.js", "Scripts/Entities/Account/FormLibrary.js"])
    .pipe(concat("FormLibrary.js"))
    .pipe(dest("bundles/Entities/Account"))
});

