"use strict";
/**
 * Author: Parth
 * Version: 1.0.0.0
 * Instruction to get started:
 * Make this file part of your project
 * Follow the blog: https://medium.com/gulpjs/gulp-sips-command-line-interface-e53411d4467 for proper gulp installation
 * Install below packages:
 * npm install ts-node --save-dev
 * npm install typescript --save
 * npm install @types/node --save-dev
 * npm install --save-dev gulp-uglify
 * npm install --save-dev gulp-concat
 * npm install gulp
 * First install npm install --save-dev gulp-js-obfuscator
 * if above doesn't work in your case then install npm install --save gulp-javascript-obfuscator
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _a = require('gulp'), src = _a.src, dest = _a.dest, task = _a.task;
var uglifyjs = require('uglify-js');
var uglify = require('gulp-uglify');
var composer = require('gulp-uglify/composer');
var concat = require('gulp-concat');
// const javascriptObfuscator = require('gulp-javascript-obfuscator'); // based on what you use, uncomment this and comment the below one.
var jsObfuscator = require('gulp-js-obfuscator');
/**
 * Kindly put the proper path
 * srcPath will be the path of your JS
 * destPath will be the Output Directory of your JS
 */
var srcPaths = ["Scripts/Common/Utility.js", "Scripts/Entities/TableConfiguration/FormLibrary.js"];
// Example: let srcPaths: string[] = ['scripts/**/*.js', '!scripts/vendor/**', 'scripts/vendor/react.js'];
var destPath = "bundles/";
// This is to create the object of uglifyjs which can be later down use to pass the various parameters
// various available parameters: https://github.com/mishoo/UglifyJS2#minify-options
var minify = composer(uglifyjs, console);
// Created an object with the necessary parameters for uglification
var options = { mangle: { toplevel: true, eval: true } };
// ar options = { compress : { }  };
// Use following command: gulp concat-account-form
task('concat-account-form', function () {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            src(["Scripts/Common/Utility.js", "Scripts/Entities/Account/FormLibrary.js"])
                .pipe(concat("FormLibrary.js"))
                .pipe(dest("bundles/Entities/Account"));
            return [2 /*return*/];
        });
    });
});
//# sourceMappingURL=gulpfile.js.map