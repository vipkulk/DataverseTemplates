﻿namespace $safeprojectname$
{
    public static class ContactTable
    {
        public const string FirstName = "firstname";
        public const string LastName = "lastname";
        public const string Status = "statecode";
        public const string Customer = "parentaccountid";
    }
}
