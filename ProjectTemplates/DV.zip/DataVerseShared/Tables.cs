﻿namespace $safeprojectname$
{
    public static class Tables
    {
        public const string Contact = "contact";
        public const string Account = "account";
    }
}
