﻿namespace $safeprojectname$
{
    public static class ContactStatus
    {
        public const int Active = 0;
        public const int InActive = 1;
    }
}
