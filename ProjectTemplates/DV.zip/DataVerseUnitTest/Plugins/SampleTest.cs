﻿using FakeXrmEasy;
using Microsoft.Xrm.Sdk;
using Xunit;

namespace $safeprojectname$.Plugins
{
    public class SampleTest
    {
        [Fact]
        public void SamplePluginTestWithTaregt()
        {
            //Arrange
            var target = new Entity("<name from shared project>");
            var preImage = new Entity("<name from shared project>");
            var context = new XrmFakedContext();

            //Act
              //context.ExecutePluginWithTarget<Sample>(target);

            //Assert
            var service = context.GetOrganizationService();
             // Code for Asserting logic 
        }

        [Fact]
        public void SamplePluginTestWithTargetandImage()
        {
            //Arrange
            var target = new Entity("<name from shared project>");
            var preImage = new Entity("<name from shared project>");
            var context = new XrmFakedContext();
            var pluginContext = new XrmFakedPluginExecutionContext()
            {
                InputParameters =
                {
                    { "Target", target }
                },
                PreEntityImages =
                {
                    {"Image", preImage}
                },
                MessageName = "Update",
            };

            //Act
            //context.ExecutePluginWith<Sample>(pluginContext);

            //Assert
        }
    }
}
